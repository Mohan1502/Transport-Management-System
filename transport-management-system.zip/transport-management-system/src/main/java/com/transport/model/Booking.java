package com.transport.model;

import java.time.LocalDate;

public class Booking {
    private int bookingId;
    private String passengerName;
    private Route route;
    private Vehicle vehicle;
    private Driver driver;
    private LocalDate travelDate;
    private String status; // Confirmed, Cancelled, Completed

    public Booking(int bookingId, String passengerName, Route route, Vehicle vehicle,
                    Driver driver, LocalDate travelDate, String status) {
        this.bookingId = bookingId;
        this.passengerName = passengerName;
        this.route = route;
        this.vehicle = vehicle;
        this.driver = driver;
        this.travelDate = travelDate;
        this.status = status;
    }

    public int getBookingId() { return bookingId; }
    public String getPassengerName() { return passengerName; }
    public Route getRoute() { return route; }
    public Vehicle getVehicle() { return vehicle; }
    public Driver getDriver() { return driver; }
    public LocalDate getTravelDate() { return travelDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return String.format(
            "Booking[id=%d, passenger=%s, route=%s -> %s, vehicle=%s, driver=%s, date=%s, status=%s]",
            bookingId, passengerName, route.getSource(), route.getDestination(),
            vehicle.getVehicleNumber(), driver.getName(), travelDate, status);
    }
}
