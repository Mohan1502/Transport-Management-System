package com.transport.model;

public class Route {
    private int routeId;
    private String source;
    private String destination;
    private double distanceKm;
    private double fare;

    public Route(int routeId, String source, String destination, double distanceKm, double fare) {
        this.routeId = routeId;
        this.source = source;
        this.destination = destination;
        this.distanceKm = distanceKm;
        this.fare = fare;
    }

    public int getRouteId() { return routeId; }
    public String getSource() { return source; }
    public String getDestination() { return destination; }
    public double getDistanceKm() { return distanceKm; }
    public double getFare() { return fare; }

    @Override
    public String toString() {
        return String.format("Route[id=%d, from=%s, to=%s, distance=%.1fkm, fare=%.2f]",
                routeId, source, destination, distanceKm, fare);
    }
}
