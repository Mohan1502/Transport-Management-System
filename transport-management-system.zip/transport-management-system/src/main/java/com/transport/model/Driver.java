package com.transport.model;

public class Driver {
    private int driverId;
    private String name;
    private String licenseNumber;
    private String contactNumber;
    private boolean available;

    public Driver(int driverId, String name, String licenseNumber, String contactNumber, boolean available) {
        this.driverId = driverId;
        this.name = name;
        this.licenseNumber = licenseNumber;
        this.contactNumber = contactNumber;
        this.available = available;
    }

    public int getDriverId() { return driverId; }
    public String getName() { return name; }
    public String getLicenseNumber() { return licenseNumber; }
    public String getContactNumber() { return contactNumber; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return String.format("Driver[id=%d, name=%s, license=%s, contact=%s, available=%s]",
                driverId, name, licenseNumber, contactNumber, available);
    }
}
