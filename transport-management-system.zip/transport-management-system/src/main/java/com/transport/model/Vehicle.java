package com.transport.model;

public class Vehicle {
    private int vehicleId;
    private String vehicleNumber;
    private String type;       // e.g. Bus, Truck, Van
    private int capacity;
    private String status;     // Available, On Trip, Maintenance

    public Vehicle(int vehicleId, String vehicleNumber, String type, int capacity, String status) {
        this.vehicleId = vehicleId;
        this.vehicleNumber = vehicleNumber;
        this.type = type;
        this.capacity = capacity;
        this.status = status;
    }

    public int getVehicleId() { return vehicleId; }
    public String getVehicleNumber() { return vehicleNumber; }
    public String getType() { return type; }
    public int getCapacity() { return capacity; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("Vehicle[id=%d, number=%s, type=%s, capacity=%d, status=%s]",
                vehicleId, vehicleNumber, type, capacity, status);
    }
}
