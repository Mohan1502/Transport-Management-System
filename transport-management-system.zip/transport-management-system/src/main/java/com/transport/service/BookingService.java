package com.transport.service;

import com.transport.dao.TransportRepository;
import com.transport.model.*;

import java.time.LocalDate;
import java.util.Optional;

public class BookingService {

    private final TransportRepository repo;

    public BookingService(TransportRepository repo) {
        this.repo = repo;
    }

    /**
     * Books a trip: picks the first available vehicle & driver, creates a booking,
     * and marks them as busy.
     */
    public Booking bookTrip(String passengerName, int routeId, LocalDate travelDate) {
        Route route = repo.getRoute(routeId);
        if (route == null) {
            throw new IllegalArgumentException("Route not found: " + routeId);
        }

        Optional<Vehicle> availableVehicle = repo.getAllVehicles().stream()
                .filter(v -> "Available".equalsIgnoreCase(v.getStatus()))
                .findFirst();

        Optional<Driver> availableDriver = repo.getAllDrivers().stream()
                .filter(Driver::isAvailable)
                .findFirst();

        if (availableVehicle.isEmpty()) {
            throw new IllegalStateException("No vehicles available right now.");
        }
        if (availableDriver.isEmpty()) {
            throw new IllegalStateException("No drivers available right now.");
        }

        Vehicle vehicle = availableVehicle.get();
        Driver driver = availableDriver.get();

        vehicle.setStatus("On Trip");
        driver.setAvailable(false);

        Booking booking = new Booking(
                repo.nextBookingId(), passengerName, route, vehicle, driver, travelDate, "Confirmed"
        );
        return repo.addBooking(booking);
    }

    public void cancelBooking(int bookingId) {
        Booking booking = repo.getBooking(bookingId);
        if (booking == null) {
            throw new IllegalArgumentException("Booking not found: " + bookingId);
        }
        booking.setStatus("Cancelled");
        booking.getVehicle().setStatus("Available");
        booking.getDriver().setAvailable(true);
    }

    public void completeBooking(int bookingId) {
        Booking booking = repo.getBooking(bookingId);
        if (booking == null) {
            throw new IllegalArgumentException("Booking not found: " + bookingId);
        }
        booking.setStatus("Completed");
        booking.getVehicle().setStatus("Available");
        booking.getDriver().setAvailable(true);
    }
}
