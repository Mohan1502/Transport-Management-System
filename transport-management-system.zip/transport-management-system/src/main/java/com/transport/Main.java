package com.transport;

import com.transport.dao.TransportRepository;
import com.transport.model.*;
import com.transport.service.BookingService;

import java.time.LocalDate;
import java.util.Scanner;

public class Main {

    private static final TransportRepository repo = new TransportRepository();
    private static final BookingService bookingService = new BookingService(repo);

    public static void main(String[] args) {
        seedData();

        Scanner sc = new Scanner(System.in);
        boolean running = true;

        while (running) {
            printMenu();
            String choice = sc.nextLine().trim();

            switch (choice) {
                case "1" -> listVehicles();
                case "2" -> listDrivers();
                case "3" -> listRoutes();
                case "4" -> bookTrip(sc);
                case "5" -> listBookings();
                case "6" -> cancelBooking(sc);
                case "7" -> completeBooking(sc);
                case "0" -> running = false;
                default -> System.out.println("Invalid option. Try again.\n");
            }
        }
        System.out.println("Exiting Transport Management System. Bye!");
    }

    private static void seedData() {
        repo.addVehicle("TN-01-AB-1234", "Bus", 40, "Available");
        repo.addVehicle("TN-02-CD-5678", "Van", 12, "Available");
        repo.addVehicle("TN-03-EF-9012", "Truck", 8, "Maintenance");

        repo.addDriver("Ravi Kumar", "DL-TN-001", "9876543210", true);
        repo.addDriver("Suresh Babu", "DL-TN-002", "9876500000", true);
        repo.addDriver("Vijay Anand", "DL-TN-003", "9876511111", false);

        repo.addRoute("Chennai", "Bangalore", 350, 850.0);
        repo.addRoute("Chennai", "Madurai", 460, 1050.0);
        repo.addRoute("Chennai", "Coimbatore", 500, 1150.0);
    }

    private static void printMenu() {
        System.out.println("========== TRANSPORT MANAGEMENT SYSTEM ==========");
        System.out.println("1. View Vehicles");
        System.out.println("2. View Drivers");
        System.out.println("3. View Routes");
        System.out.println("4. Book a Trip");
        System.out.println("5. View Bookings");
        System.out.println("6. Cancel Booking");
        System.out.println("7. Complete Booking");
        System.out.println("0. Exit");
        System.out.print("Choose an option: ");
    }

    private static void listVehicles() {
        System.out.println("\n-- Vehicles --");
        repo.getAllVehicles().forEach(System.out::println);
        System.out.println();
    }

    private static void listDrivers() {
        System.out.println("\n-- Drivers --");
        repo.getAllDrivers().forEach(System.out::println);
        System.out.println();
    }

    private static void listRoutes() {
        System.out.println("\n-- Routes --");
        repo.getAllRoutes().forEach(System.out::println);
        System.out.println();
    }

    private static void listBookings() {
        System.out.println("\n-- Bookings --");
        repo.getAllBookings().forEach(System.out::println);
        System.out.println();
    }

    private static void bookTrip(Scanner sc) {
        try {
            System.out.print("Passenger name: ");
            String name = sc.nextLine().trim();

            listRoutes();
            System.out.print("Enter Route ID: ");
            int routeId = Integer.parseInt(sc.nextLine().trim());

            Booking booking = bookingService.bookTrip(name, routeId, LocalDate.now().plusDays(1));
            System.out.println("Booking successful!\n" + booking + "\n");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage() + "\n");
        }
    }

    private static void cancelBooking(Scanner sc) {
        try {
            System.out.print("Enter Booking ID to cancel: ");
            int id = Integer.parseInt(sc.nextLine().trim());
            bookingService.cancelBooking(id);
            System.out.println("Booking " + id + " cancelled.\n");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage() + "\n");
        }
    }

    private static void completeBooking(Scanner sc) {
        try {
            System.out.print("Enter Booking ID to mark complete: ");
            int id = Integer.parseInt(sc.nextLine().trim());
            bookingService.completeBooking(id);
            System.out.println("Booking " + id + " marked as completed.\n");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage() + "\n");
        }
    }
}
