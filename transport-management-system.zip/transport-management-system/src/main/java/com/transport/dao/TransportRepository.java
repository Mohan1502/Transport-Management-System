package com.transport.dao;

import com.transport.model.*;

import java.util.*;

/**
 * Simple in-memory repository (acts like a DAO layer).
 * Can be swapped later with a real database (JDBC/JPA) implementation.
 */
public class TransportRepository {

    private final Map<Integer, Vehicle> vehicles = new LinkedHashMap<>();
    private final Map<Integer, Driver> drivers = new LinkedHashMap<>();
    private final Map<Integer, Route> routes = new LinkedHashMap<>();
    private final Map<Integer, Booking> bookings = new LinkedHashMap<>();

    private int vehicleSeq = 1;
    private int driverSeq = 1;
    private int routeSeq = 1;
    private int bookingSeq = 1;

    // ---------- Vehicle ----------
    public Vehicle addVehicle(String number, String type, int capacity, String status) {
        Vehicle v = new Vehicle(vehicleSeq++, number, type, capacity, status);
        vehicles.put(v.getVehicleId(), v);
        return v;
    }
    public Collection<Vehicle> getAllVehicles() { return vehicles.values(); }
    public Vehicle getVehicle(int id) { return vehicles.get(id); }

    // ---------- Driver ----------
    public Driver addDriver(String name, String license, String contact, boolean available) {
        Driver d = new Driver(driverSeq++, name, license, contact, available);
        drivers.put(d.getDriverId(), d);
        return d;
    }
    public Collection<Driver> getAllDrivers() { return drivers.values(); }
    public Driver getDriver(int id) { return drivers.get(id); }

    // ---------- Route ----------
    public Route addRoute(String source, String destination, double distanceKm, double fare) {
        Route r = new Route(routeSeq++, source, destination, distanceKm, fare);
        routes.put(r.getRouteId(), r);
        return r;
    }
    public Collection<Route> getAllRoutes() { return routes.values(); }
    public Route getRoute(int id) { return routes.get(id); }

    // ---------- Booking ----------
    public Booking addBooking(Booking b) {
        bookings.put(b.getBookingId(), b);
        return b;
    }
    public int nextBookingId() { return bookingSeq++; }
    public Collection<Booking> getAllBookings() { return bookings.values(); }
    public Booking getBooking(int id) { return bookings.get(id); }
}
