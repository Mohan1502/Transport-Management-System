# Transport Management System

A simple console-based **Transport Management System** built with core Java (Maven project).

## Features
- Manage Vehicles (Bus, Van, Truck) with capacity & status
- Manage Drivers with license & availability
- Manage Routes with distance & fare
- Book a trip (auto-assigns an available vehicle + driver)
- Cancel / complete bookings
- View all vehicles, drivers, routes, and bookings

## Project Structure
```
transport-management-system/
├── pom.xml
└── src/main/java/com/transport
    ├── Main.java                     # Console app entry point
    ├── model/
    │   ├── Vehicle.java
    │   ├── Driver.java
    │   ├── Route.java
    │   └── Booking.java
    ├── dao/
    │   └── TransportRepository.java  # In-memory data store
    └── service/
        └── BookingService.java       # Business logic for bookings
```

## How to Build & Run

### Requirements
- Java 17+
- Maven 3.6+

### Build
```bash
mvn clean package
```

### Run
```bash
java -cp target/classes com.transport.Main
```
or, after packaging:
```bash
java -jar target/transport-management-system.jar
```

## Notes
- Data is stored in-memory (resets every run). To persist data, replace
  `TransportRepository` with a JDBC/JPA-backed implementation connected to
  MySQL/PostgreSQL — the rest of the code (service layer, Main) won't need
  to change since it only depends on the repository's public methods.
- Sample vehicles, drivers, and routes are pre-loaded when the app starts
  (see `Main.seedData()`).
